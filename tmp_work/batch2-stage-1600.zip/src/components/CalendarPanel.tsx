import { useMemo, useState } from 'react'
import type { Dependency, Graph, ScoredReport, SchedulePrecision } from '../lib/types'
import type { NodePredicate } from '../lib/filter'
import { colourForReport } from '../lib/palette'
import { SEARCH_BAR_LEFT, SEARCH_BAR_WIDTH } from './SearchPanel'
import {
  calendarEvents,
  describeWindow,
  horizonWindow,
  HORIZONS,
  type CalendarEvent,
  type Horizon,
} from '../lib/schedule'
import { HUD_TOP } from '../lib/uiTheme'

/**
 * What is coming, and what quietly consumes it.
 *
 * Sits along the bottom edge because it is a timeline and a timeline wants
 * width, and because the two side panels already own the vertical edges. Rolls
 * away behind a tab like they do.
 *
 * Two things are on it. **Releases** come from each report's `release_schedule`
 * and are what any publisher's own calendar would show. **Reads** come from the
 * *edges* — `reference_period` says when a dependent actually consumes its
 * source — and are the thing no publisher can tell you, because the fact does
 * not belong to either document alone. Turning reads off leaves an ordinary
 * release calendar, which is the useful comparison: the difference between the
 * two is the graph earning its keep.
 *
 * ### Fuzziness is drawn, not resolved
 *
 * An entry is a window, and windows of different widths are not the same claim.
 * "17 August" and "sometime in Q3" both have to appear, and the second must not
 * be quietly rendered as a point — a midpoint looks like a date, and a date
 * nobody stated is exactly the kind of invention the corpus refuses everywhere
 * else. So precision is drawn as width, and a fortnight-wide bar reads as a
 * fortnight-wide claim.
 *
 * ### It says what it cannot show
 *
 * The footer counts what did not make it: recurring reports carrying no
 * schedule yet, reports whose timing is honestly irregular, and edges that
 * state a reading with no anchor to hang it on. Without that line an empty
 * calendar and an unresearched one look identical, and the empty one is far
 * rarer than it would appear.
 */
export default function CalendarPanel({
  graph,
  dependencies,
  within,
  onChoose,
  compact = false,
  collapsed: controlledCollapsed,
  onCollapsedChange,
}: {
  graph: Graph
  dependencies: Dependency[]
  /** The scope filter, so the calendar never lists a report the graph is hiding. */
  within: NodePredicate
  onChoose: (report: ScoredReport) => void
  /**
   * Compact layout (2026-08-31, second audit F-12 — see
   * `lib/useCompactLayout.ts`): the parent owns `collapsed`, the Panels ▾
   * submenu drives it, and the tab beside the search bar is not drawn. The
   * panel itself stays centred but clamps to the window width.
   */
  compact?: boolean
  collapsed?: boolean
  onCollapsedChange?: (collapsed: boolean) => void
}) {
  const [innerCollapsed, setInnerCollapsed] = useState(true)
  const collapsed = controlledCollapsed ?? innerCollapsed
  const setCollapsed = (next: boolean | ((c: boolean) => boolean)) => {
    const value = typeof next === 'function' ? next(collapsed) : next
    if (onCollapsedChange) onCollapsedChange(value)
    if (controlledCollapsed === undefined) setInnerCollapsed(value)
  }
  const [horizon, setHorizon] = useState<Horizon>('month')
  const [showReads, setShowReads] = useState(true)

  // The graph already carries this exact lookup — building a second identical
  // map here was pure redundancy (tidied 2026-08-12).
  const byId = graph.byId

  const { events, unplaceable } = useMemo(() => {
    const w = horizonWindow(horizon)
    return calendarEvents(graph.nodes, dependencies, w)
  }, [graph, dependencies, horizon])

  // Filtering happens here rather than inside `calendarEvents` so the
  // unplaceable counts stay honest about the whole corpus: "nothing is due"
  // because of a filter and "nothing is due" because nothing is researched are
  // different answers and the footer has to keep saying the second one.
  const shown = useMemo(
    () =>
      events.filter((e) => {
        if (e.kind === 'read' && !showReads) return false
        // The horizon is a rhythm, not just a window — see `cadenceBand`. A
        // quarter view widened without this is three months of monthly releases
        // with the quarterlies lost inside them, which is what the panel looked
        // like on first sight. `all` is the escape hatch: same year-long window,
        // no band filter, for when the question really is "everything".
        if (horizon !== 'all' && e.band !== horizon) return false
        const r = byId.get(e.reportId)
        if (!r || !within(r)) return false
        if (e.readerId) {
          const reader = byId.get(e.readerId)
          // A read is an event about two reports. Hiding one of them hides the
          // event, or the calendar would show a consumer that is not on screen.
          if (!reader || !within(reader)) return false
        }
        return true
      }),
    [events, showReads, within, byId, horizon],
  )

  // Group by the window's own description, so a run of quarter-wide entries
  // collects under one "Q4 2026" heading instead of scattering across the days
  // they happen to start on.
  const groups = useMemo(() => {
    const out: { label: string; events: CalendarEvent[] }[] = []
    for (const e of shown) {
      const label = describeWindow(e.from, e.to, e.precision)
      const last = out[out.length - 1]
      if (last && last.label === label) last.events.push(e)
      else out.push({ label, events: [e] })
    }
    return out
  }, [shown])

  const missing =
    unplaceable.reportsWithoutSchedule.length +
    unplaceable.reportsIrregular.length +
    unplaceable.edgesWithoutAnchor.length +
    unplaceable.edgesSubAnnualUnphased.length

  return (
    <>
      <div
        style={{
          // Top of the screen, dropping down from under its own button —
          // Thomas, 2026-08-12 round-7 feedback: "the calendar opens at the
          // bottom, that should go up top with the calendar button." The
          // bottom edge it used to slide from now belongs to the chip bar and
          // the tier buttons, and the three were fighting for the same
          // pixels. Slides DOWN from above the viewport instead of up from
          // below it; same tab, same animation, opposite edge.
          position: 'fixed',
          top: HUD_TOP + 44,
          left: compact ? 20 : '50%',
          width: compact ? `min(${PANEL_WIDTH}px, calc(100vw - 40px))` : PANEL_WIDTH,
          marginLeft: compact ? 0 : -PANEL_WIDTH / 2,
          transform: `translateY(${collapsed ? -(PANEL_HEIGHT + 90) : 0}px)`,
          transition: 'transform 220ms cubic-bezier(0.4, 0, 0.2, 1)',
          pointerEvents: collapsed ? 'none' : 'auto',
          zIndex: 5,
        }}
      >
        <div style={shell}>
          <div style={header}>
            <span style={heading}>Calendar</span>
            <span style={{ display: 'flex', gap: 3 }}>
              {HORIZONS.map((h) => (
                <button
                  key={h}
                  type="button"
                  onClick={() => setHorizon(h)}
                  style={{
                    ...chip,
                    color: h === horizon ? 'var(--ink-strong)' : 'var(--ink-dim)',
                    borderColor:
                      h === horizon
                        ? 'var(--accent-line)'
                        : 'var(--line)',
                    background:
                      h === horizon ? 'var(--accent-soft)' : 'transparent',
                  }}
                >
                  {h}
                </button>
              ))}
            </span>
            <button
              type="button"
              onClick={() => setShowReads((s) => !s)}
              title={
                showReads
                  ? 'Hide the downstream reads and leave an ordinary release calendar'
                  : 'Show when dependents actually consume each release'
              }
              style={{
                ...chip,
                marginLeft: 'auto',
                color: showReads ? 'var(--ink-strong)' : 'var(--ink-dim)',
                borderColor: showReads
                  ? 'var(--accent-line)'
                  : 'var(--line)',
                background: showReads ? 'var(--accent-soft)' : 'transparent',
              }}
            >
              reads
            </button>
          </div>

          <div style={body}>
            {groups.length === 0 && (
              <div style={empty}>
                Nothing on this rhythm in this window.
                {missing > 0 && ' Which is not the same as nothing happening — see below.'}
              </div>
            )}
            {groups.map((g) => (
              <div key={g.label + g.events[0].reportId} style={{ marginBottom: 10 }}>
                <div style={groupLabel}>{g.label}</div>
                {g.events.map((e, i) => {
                  const r = byId.get(e.reportId)
                  if (!r) return null
                  const reader = e.readerId ? byId.get(e.readerId) : undefined
                  return (
                    <div
                      key={`${e.kind}-${e.reportId}-${e.readerId ?? ''}-${e.from}-${i}`}
                      onClick={() => onChoose(reader ?? r)}
                      style={row}
                      title={e.detail}
                    >
                      <PrecisionMark
                        precision={e.precision}
                        colour={colourForReport(r)}
                        read={e.kind === 'read'}
                      />
                      <span style={{ flex: 1, minWidth: 0 }}>
                        <span style={title}>
                          {e.kind === 'read' ? (
                            <>
                              <span style={{ color: 'var(--ink-mute)' }}>{r.title}</span>
                              <span style={{ color: 'var(--ink-faint)' }}> read by </span>
                              {reader?.title ?? e.readerId}
                            </>
                          ) : (
                            r.title
                          )}
                        </span>
                        <span style={sub}>
                          {e.kind === 'read'
                            ? (reader?.publisher ?? '')
                            : r.publisher}
                          {e.detail ? ` · ${trim(e.detail)}` : ''}
                        </span>
                      </span>
                      {e.evidence === 'implied' && (
                        <span
                          style={impliedTag}
                          title={
                            e.kind === 'read'
                              ? 'The document gives a rate and one date; the rest of these readings are arithmetic'
                              : 'Inferred from past releases, not read off a published calendar'
                          }
                        >
                          implied
                        </span>
                      )}
                    </div>
                  )
                })}
              </div>
            ))}
          </div>

          {missing > 0 && (
            <div style={footer}>
              Not shown:{' '}
              {unplaceable.reportsWithoutSchedule.length > 0 && (
                <>
                  <b style={b}>{unplaceable.reportsWithoutSchedule.length}</b> recurring
                  reports with no schedule researched
                </>
              )}
              {unplaceable.reportsIrregular.length > 0 && (
                <>
                  {unplaceable.reportsWithoutSchedule.length > 0 && ', '}
                  <b style={b}>{unplaceable.reportsIrregular.length}</b> irregular
                </>
              )}
              {unplaceable.edgesWithoutAnchor.length > 0 && (
                <>
                  {', '}
                  <b style={b}>{unplaceable.edgesWithoutAnchor.length}</b> edges stating a
                  reading with no date
                </>
              )}
              {unplaceable.edgesSubAnnualUnphased.length > 0 && (
                <>
                  {(unplaceable.reportsWithoutSchedule.length > 0 ||
                    unplaceable.reportsIrregular.length > 0 ||
                    unplaceable.edgesWithoutAnchor.length > 0) &&
                    ', '}
                  <b style={b}>{unplaceable.edgesSubAnnualUnphased.length}</b> edges
                  reading less than once a year (no year to phase them against)
                </>
              )}
              .
            </div>
          )}
        </div>
      </div>

      {!compact && (
      <button
        type="button"
        onClick={() => setCollapsed((c) => !c)}
        title={collapsed ? 'Show Calendar' : 'Hide Calendar'}
        aria-expanded={!collapsed}
        style={{
          // **Top, beside the search bar — not bottom-centre any more.**
          //
          // It used to sit at the bottom, tucked against the panel it opens,
          // which was right until the tier buttons took that exact spot. The
          // two then overlapped, and Thomas asked for it moved: *"'Calendar'
          // can be set on the left of the search bar, add a calendar icon too.
          // I think that will clean up the hud."*
          //
          // **Flipped to the search bar's RIGHT, 2026-08-20**, when the search
          // bar itself moved off dead-centre to `SEARCH_BAR_LEFT` (Thomas: "I
          // just want the search/find bar to the left... add it to the right
          // at the top of the page") — staying on the search bar's left edge
          // would have pushed this tab further left still, straight into the
          // Reports `PanelShell` the search bar itself was just moved to
          // avoid. Anchored off the search bar's own left edge plus its
          // width, same 8px gap as before, no `translateX` needed now that
          // the tab grows away from the bar instead of towards it.
          position: 'fixed',
          top: HUD_TOP,
          left: SEARCH_BAR_LEFT + SEARCH_BAR_WIDTH + 8,
          display: 'flex',
          alignItems: 'center',
          gap: 6,
          padding: '9px 12px',
          fontFamily: 'inherit',
          fontSize: 10,
          letterSpacing: '0.08em',
          textTransform: 'uppercase',
          // Lit while the panel is open, the same treatment the tier buttons
          // use — with the button no longer touching the panel it toggles, its
          // own appearance is the only thing left saying whether that panel is
          // up.
          color: collapsed ? 'var(--ink-dim)' : 'var(--ink-strong)',
          background: collapsed ? 'var(--panel-bg)' : 'var(--accent-active)',
          border: `1px solid ${collapsed ? 'var(--line)' : 'var(--line-strong)'}`,
          borderRadius: 6,
          boxShadow: 'var(--panel-shadow)',
          backdropFilter: 'var(--glass-filter)',
          cursor: 'pointer',
          zIndex: 6,
          lineHeight: 1,
          whiteSpace: 'nowrap',
        }}
      >
        <span aria-hidden style={{ fontSize: 12, lineHeight: 1 }}>
          📆
        </span>
        Calendar
      </button>
      )}
    </>
  )
}

/**
 * Precision as width.
 *
 * A known day is a dot; everything vaguer is a bar as wide as the claim. This
 * is the one piece of the panel that must not be tidied into uniformity — the
 * whole reason the schema keeps precision per entry is so that a Q3 estimate
 * cannot be mistaken for a date, and the mark is where that survives or dies.
 *
 * A read is drawn hollow. It is the same colour as the report being consumed,
 * because that is what the event is about, but it is not a publication and
 * should not read as one at a glance.
 */
function PrecisionMark({
  precision,
  colour,
  read,
}: {
  precision: SchedulePrecision
  colour: string
  read: boolean
}) {
  const width = MARK_WIDTH[precision]
  return (
    <span
      style={{
        width,
        minWidth: width,
        height: 7,
        borderRadius: 4,
        marginTop: 4,
        background: read ? 'transparent' : colour,
        border: read ? `1px solid ${colour}` : 'none',
        boxSizing: 'border-box',
      }}
    />
  )
}

const MARK_WIDTH: Record<SchedulePrecision, number> = {
  day: 7,
  week: 12,
  month: 20,
  quarter: 30,
  half: 42,
  year: 56,
}

/** Reference-period quotations run long; the full text is in the row's title. */
function trim(s: string): string {
  return s.length > 90 ? `${s.slice(0, 88)}…` : s
}

const PANEL_WIDTH = 560
const PANEL_HEIGHT = 300

const shell: React.CSSProperties = {
  background: 'var(--panel-bg)',
  border: '1px solid var(--line)',
  borderRadius: 10,
  boxShadow: 'var(--panel-shadow)',
  backdropFilter: 'var(--glass-filter)',
  padding: '10px 12px 8px',
  boxSizing: 'border-box',
  height: PANEL_HEIGHT,
  display: 'flex',
  flexDirection: 'column',
}

const header: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  marginBottom: 8,
}

const heading: React.CSSProperties = {
  fontSize: 10,
  letterSpacing: '0.08em',
  textTransform: 'uppercase',
  color: 'var(--ink-dim)',
}

const chip: React.CSSProperties = {
  fontFamily: 'inherit',
  fontSize: 10,
  letterSpacing: '0.04em',
  padding: '3px 7px',
  borderRadius: 5,
  border: '1px solid var(--line)',
  cursor: 'pointer',
  lineHeight: 1,
}

const body: React.CSSProperties = {
  flex: 1,
  overflowY: 'auto',
  marginRight: -6,
  paddingRight: 6,
}

const groupLabel: React.CSSProperties = {
  fontSize: 10,
  letterSpacing: '0.06em',
  textTransform: 'uppercase',
  color: 'var(--ink-faint)',
  marginBottom: 3,
}

const row: React.CSSProperties = {
  display: 'flex',
  gap: 8,
  alignItems: 'flex-start',
  padding: '3px 4px',
  borderRadius: 5,
  cursor: 'pointer',
}

const title: React.CSSProperties = {
  color: 'var(--ink-strong)',
  fontSize: 12,
  lineHeight: 1.35,
  display: 'block',
}

const sub: React.CSSProperties = {
  display: 'block',
  color: 'var(--ink-mute)',
  fontSize: 10.5,
  marginTop: 1,
}

const impliedTag: React.CSSProperties = {
  fontSize: 9,
  letterSpacing: '0.06em',
  textTransform: 'uppercase',
  color: '#8a7ab5',
  marginTop: 4,
  flexShrink: 0,
}

const empty: React.CSSProperties = {
  color: 'var(--ink-mute)',
  fontSize: 11.5,
  lineHeight: 1.5,
  padding: '6px 2px',
}

const footer: React.CSSProperties = {
  borderTop: '1px solid var(--line-faint)',
  paddingTop: 6,
  marginTop: 6,
  color: 'var(--ink-dim)',
  fontSize: 10.5,
  lineHeight: 1.45,
}

const b: React.CSSProperties = { color: 'var(--ink-label)', fontWeight: 600 }
