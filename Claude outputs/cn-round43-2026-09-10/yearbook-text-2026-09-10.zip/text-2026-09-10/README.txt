Yearbook layer TEXT, extracted 2026-09-10 (round 43) with pdftotext (no -layout) / tag-stripping, kept so the next round can grep without refetching.
File name = <set>-<file>.txt. Sets: nat = https://www.stats.gov.cn/sj/ndsj/2025/html/ (sm01-29.htm, zb01-27.pdf, ALL read incl. zb10/zb27);
sd = http://tjj.shandong.gov.cn/tjnj/nj2025/zk/html/ (sm01-25, zb01-21); hn = http://222.240.193.190/2025tjnj/zk/html/ (zb01-19);
suz = https://tjj.suzhou.gov.cn/sztjj/tjnj/2025/2025/zk/html/ (zb01-19); xa = https://tjj.xa.gov.cn/tjnj/2025/zk/html/ (zb01-22, sm16, sm17);
gd/ = Guangdong CD zip 4810393.zip directory/NN/{indicators,brief-description}.html.
This is a scratch copy for grepping. It is NOT evidence: cite and grade against the live URL, never against these files.
